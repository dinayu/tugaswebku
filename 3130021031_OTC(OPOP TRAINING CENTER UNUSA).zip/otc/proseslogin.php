<?php
// Koneksi ke database
$host = 'localhost';
$user = 'root';
$pass = '';
$db   = 'otc';

$koneksi = new mysqli($host, $user, $pass, $db);

if ($koneksi->connect_error) {
    die("Koneksi database gagal: " . $koneksi->connect_error);
}

// Mendapatkan data dari form
$username = $_POST['user'];
$password = $_POST['pass'];

// Menggunakan prepared statement untuk mencegah SQL injection
$query = $koneksi->prepare("SELECT COUNT(username) AS jumlah FROM admin 
                           WHERE username=? AND password=?");
$query->bind_param('ss', $username, $password);
$query->execute();

$result = $query->get_result();
$data = $result->fetch_assoc();
$jumlah = $data['jumlah'];

if ($jumlah >= 1) {
    session_start();
    $_SESSION['username'] = $username;

    echo "<script>alert('Selamat datang $username'); window.location = 'admin/tambah.php'</script>";
} else {
    echo "<script>alert('Username dan Password tidak valid.'); window.location = 'index.html'</script>";
}

// Menutup koneksi
$query->close();
$koneksi->close();
?>
